import React, { useState } from 'react';
import {
  Sparkles,
  Download,
  FileCode,
  FolderArchive,
  Search,
  Filter,
  Eye,
  Github,
  Volume2,
  VolumeX,
  Lock,
  ArrowLeft,
  ExternalLink,
  ShieldCheck,
  Check,
  Copy
} from 'lucide-react';
import { UploadedItem } from '../types';
import { downloadTextOrBlobFile } from '../utils/githubZip';
import { soundEngine } from '../utils/audio';
import { incrementDownloadCount } from '../utils/storage';

interface PublicShowcaseProps {
  items: UploadedItem[];
  onOpenAdmin: () => void;
  isAdminLoggedIn: boolean;
  onOpenAdminDashboard: () => void;
  onViewLua: (item: UploadedItem) => void;
  onOpenGitHubZip: () => void;
  onBackToLanding: () => void;
}

export const PublicShowcase: React.FC<PublicShowcaseProps> = ({
  items,
  onOpenAdmin,
  isAdminLoggedIn,
  onOpenAdminDashboard,
  onViewLua,
  onOpenGitHubZip,
  onBackToLanding
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'lua' | 'zip'>('all');
  const [isPlayingAudio, setIsPlayingAudio] = useState(soundEngine.isPlaying());
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleAudio = () => {
    const next = soundEngine.toggleKicauMania();
    setIsPlayingAudio(next);
  };

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());

    if (filterType === 'all') return matchesSearch;
    return matchesSearch && item.fileType === filterType;
  });

  const handleDownloadFile = (item: UploadedItem) => {
    incrementDownloadCount(item.id);
    soundEngine.playSuccessSound();

    if (item.fileType === 'lua' && item.luaContent) {
      downloadTextOrBlobFile(item.fileName, item.luaContent, 'text/plain');
    } else {
      // Mock/real binary zip download trigger
      const dummyZipContent = `File: ${item.fileName}\nTitle: ${item.title}\nUploaded by: Krammz\nReady for execution.`;
      downloadTextOrBlobFile(item.fileName, dummyZipContent, 'application/zip');
    }
  };

  const handleQuickCopyLua = (item: UploadedItem) => {
    if (item.luaContent) {
      navigator.clipboard.writeText(item.luaContent);
      setCopiedId(item.id);
      soundEngine.playSuccessSound();
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      onViewLua(item);
    }
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-black">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Brand & Back Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToLanding}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 border border-slate-800 transition-colors"
              title="Kembali ke Animasi Gojo"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-md shadow-cyan-500/20">
                <span className="font-pixel text-[10px] text-slate-950 font-bold">K</span>
              </div>
              <div>
                <h1 className="font-pixel text-xs sm:text-sm text-cyan-300 font-bold tracking-wider">
                  krammzlua
                </h1>
                <p className="text-[10px] text-slate-400 hidden sm:block">
                  Portal Publik krammzlua • File & Script Showcase
                </p>
              </div>
            </div>
          </div>

          {/* Right Controls: Audio + GitHub Zip + Panel Admin */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Kicau Mania audio toggle */}
            <button
              onClick={toggleAudio}
              className={`p-2 sm:px-3 sm:py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                isPlayingAudio
                  ? 'bg-cyan-950/80 text-cyan-300 border-cyan-500/40 shadow-sm shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
              title="Putar / Matikan Lagu MP3 Kicau Mania"
            >
              {isPlayingAudio ? (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  <span className="hidden md:inline">Kicau Mania</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Kicau Off</span>
                </>
              )}
            </button>

            {/* GitHub .ZIP Export Button */}
            <button
              onClick={onOpenGitHubZip}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-cyan-950/80 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-400/50 transition-all shadow-sm"
              title="Download krammzlua.zip siap upload ke GitHub"
            >
              <Github className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-bold">Download krammzlua.zip</span>
              <Download className="w-3 h-3 text-cyan-300" />
            </button>

            {/* POJOK KANAN: PANEL ADMIN (Requested explicitly by user) */}
            {isAdminLoggedIn ? (
              <button
                onClick={onOpenAdminDashboard}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-md shadow-purple-900/30 border border-purple-400/30 transition-all"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
                <span>Panel Admin</span>
              </button>
            ) : (
              <button
                onClick={onOpenAdmin}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white shadow-md shadow-purple-900/30 border border-purple-400/30 transition-all cursor-pointer"
                title="Buka panel admin krammzlua"
              >
                <Lock className="w-3.5 h-3.5 text-yellow-300" />
                <span>Panel Admin</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-8 py-8 flex-1">
        {/* Banner Announcement */}
        <div className="relative mb-8 rounded-2xl bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border border-cyan-500/30 p-5 sm:p-6 overflow-hidden shadow-xl">
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  LIVE PUBLIC ACCESS
                </span>
                <span className="text-xs text-slate-400">• Bebas download tanpa registrasi</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold font-rajdhani text-white">
                SHOWCASE PUBLIK KRAMMZLUA
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
                Semua file <b>.PNG</b>, <b>.ZIP</b>, dan <b>.LUA</b> yang di-upload oleh pengelola langsung muncul dan dapat diakses oleh publik di sini.
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={isAdminLoggedIn ? onOpenAdminDashboard : onOpenAdmin}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-rajdhani uppercase tracking-wider shadow-lg shadow-cyan-500/30 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>{isAdminLoggedIn ? 'Upload File Baru' : 'Login Krammz & Upload'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari file .lua, .zip, atau nama script..."
              className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 outline-none transition-all placeholder:text-slate-500"
            />
          </div>

          {/* Filter Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filterType === 'all'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              Semua ({items.length})
            </button>

            <button
              onClick={() => setFilterType('lua')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                filterType === 'lua'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>.LUA Scripts ({items.filter((i) => i.fileType === 'lua').length})</span>
            </button>

            <button
              onClick={() => setFilterType('zip')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                filterType === 'zip'
                  ? 'bg-purple-500 text-slate-950 shadow-md shadow-purple-500/20'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>.ZIP Folders ({items.filter((i) => i.fileType === 'zip').length})</span>
            </button>
          </div>
        </div>

        {/* The Grid of Uploaded Items */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/50 border border-dashed border-slate-800 rounded-2xl p-8">
            <FolderArchive className="w-12 h-12 text-slate-600 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-300">Belum ada file yang cocok</h3>
            <p className="text-xs text-slate-500 mt-1">Coba ubah kata kunci pencarian atau upload file baru via panel admin.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              /* EXACT ORDER REQUESTED BY USER:
                 1. File .png yang diupload
                 2. Di bawahnya: Zip / lua
                 3. Di bawahnya: Nama yang ditulis saat upload
              */
              <div
                key={item.id}
                className="group relative bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-cyan-950/30 transition-all duration-300 flex flex-col"
              >
                {/* 1. BAGIAN ATAS: FILE .PNG YANG DI-UPLOAD */}
                <div className="relative w-full h-52 bg-slate-950 overflow-hidden border-b border-slate-800">
                  <img
                    src={item.imagePngUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  
                  {/* Top Badge Overlay */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-slate-950/80 text-cyan-300 px-2.5 py-1 rounded-lg border border-cyan-500/40 backdrop-blur-md">
                      🖼️ {item.imageFileName || 'PREVIEW.PNG'}
                    </span>
                  </div>

                  <div className="absolute top-3 right-3">
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border backdrop-blur-md ${
                        item.fileType === 'lua'
                          ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                          : 'bg-purple-950/80 text-purple-300 border-purple-500/50'
                      }`}
                    >
                      .{item.fileType.toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* 2. BAGIAN TENGAH (DI BAWAH PNG): FILE .ZIP / .LUA */}
                <div className="px-5 pt-4 pb-2 border-b border-slate-800/80 bg-slate-950/40">
                  <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <div
                        className={`p-2 rounded-lg shrink-0 ${
                          item.fileType === 'lua'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                        }`}
                      >
                        {item.fileType === 'lua' ? (
                          <FileCode className="w-5 h-5" />
                        ) : (
                          <FolderArchive className="w-5 h-5" />
                        )}
                      </div>

                      <div className="overflow-hidden">
                        <p className="text-xs font-bold text-slate-200 truncate font-mono">
                          {item.fileName}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          Berkas {item.fileType.toUpperCase()} • {item.fileSize}
                        </p>
                      </div>
                    </div>

                    {/* Download button for the file */}
                    <button
                      onClick={() => handleDownloadFile(item)}
                      className="px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500/15 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 transition-colors flex items-center gap-1 shrink-0"
                      title={`Download file ${item.fileName}`}
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Unduh</span>
                    </button>
                  </div>

                  {/* If Lua file, provide 1-click Quick Copy or View Script */}
                  {item.fileType === 'lua' && (
                    <div className="mt-2 flex items-center gap-2">
                      <button
                        onClick={() => handleQuickCopyLua(item)}
                        className={`flex-1 py-1 px-2 rounded-lg text-[11px] font-bold flex items-center justify-center gap-1.5 transition-all ${
                          copiedId === item.id
                            ? 'bg-emerald-500 text-slate-950 font-bold'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                        }`}
                      >
                        {copiedId === item.id ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedId === item.id ? 'Script Disalin!' : 'Copy Lua'}</span>
                      </button>

                      <button
                        onClick={() => onViewLua(item)}
                        className="py-1 px-2.5 rounded-lg text-[11px] font-bold bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 flex items-center gap-1"
                        title="Buka Code Viewer"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Lihat Kode</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* 3. BAGIAN BAWAH (DI BAWAH ZIP/LUA): NAMA FILE YANG DITULIS */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Nama yang ditulis */}
                    <h3 className="text-base font-bold text-slate-100 group-hover:text-cyan-300 transition-colors leading-snug">
                      {item.title}
                    </h3>

                    {/* Deskripsi */}
                    <p className="mt-2 text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  {/* Metadata Uploader & Date */}
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                      <span className="font-semibold text-slate-300">{item.uploader}</span>
                    </div>
                    <span>{item.uploadedAt}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-slate-800 bg-slate-950/90 py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© 2026 krammzlua • Portal Publik Gojo & Script Repository</p>
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenGitHubZip}
              className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
            >
              <Github className="w-3.5 h-3.5" />
              <span>Download krammzlua.zip</span>
            </button>
            <span>•</span>
            <button
              onClick={isAdminLoggedIn ? onOpenAdminDashboard : onOpenAdmin}
              className="text-slate-400 hover:text-slate-300"
            >
              Panel Admin
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
