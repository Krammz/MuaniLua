import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Sparkles, Radio, Play, Pause, Github, Download, Eye } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface GojoLandingPageProps {
  onEnter: () => void;
  onOpenAdmin: () => void;
  onDownloadGitHubZip: () => void;
}

export const GojoLandingPage: React.FC<GojoLandingPageProps> = ({
  onEnter,
  onOpenAdmin,
  onDownloadGitHubZip
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [volume, setVolume] = useState(0.6);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [showBirdAnimation, setShowBirdAnimation] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Audio start / toggle
  const toggleAudio = () => {
    const nextState = soundEngine.toggleKicauMania();
    setIsPlayingAudio(nextState);
    setShowBirdAnimation(nextState);
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    soundEngine.setVolume(newVol);
  };

  // Canvas animation for Gojo's Limitless Void & Cursed Energy
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particles for Cursed Energy (Blue & Violet)
    const particleCount = 70;
    const particles: {
      x: number;
      y: number;
      radius: number;
      speedX: number;
      speedY: number;
      color: string;
      alpha: number;
      pulse: number;
    }[] = [];

    const colors = [
      'rgba(56, 189, 248, ', // Cyan / Limitless Blue
      'rgba(147, 51, 234, ', // Purple / Hollow Purple
      'rgba(96, 165, 250, ', // Electric Blue
      'rgba(244, 63, 94, '   // Reverse Cursed Technique Red
    ];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 3 + 1,
        speedX: (Math.random() - 0.5) * 1.5,
        speedY: (Math.random() - 0.5) * 1.5 - 0.3,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.7 + 0.2,
        pulse: Math.random() * Math.PI
      });
    }

    let time = 0;

    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, width, height);

      // Deep void radial gradient
      const centerX = width / 2;
      const centerY = height * 0.45;
      const gradient = ctx.createRadialGradient(
        centerX,
        centerY,
        20,
        centerX,
        centerY,
        Math.max(width, height) * 0.6
      );
      gradient.addColorStop(0, 'rgba(15, 23, 42, 0.4)');
      gradient.addColorStop(0.4, 'rgba(8, 47, 73, 0.5)');
      gradient.addColorStop(0.8, 'rgba(2, 6, 23, 0.85)');
      gradient.addColorStop(1, 'rgba(2, 6, 23, 0.98)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Rotating Domain Expansion rings
      ctx.save();
      ctx.translate(centerX, centerY);
      for (let r = 1; r <= 3; r++) {
        ctx.beginPath();
        ctx.arc(0, 0, r * 90 + Math.sin(time + r) * 10, 0, Math.PI * 2);
        ctx.strokeStyle = r === 2 ? 'rgba(168, 85, 247, 0.25)' : 'rgba(56, 189, 248, 0.2)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([12, 16]);
        ctx.rotate((time * 0.1) / r);
        ctx.stroke();
      }
      ctx.restore();

      // Render Cursed Energy floating particles
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        p.pulse += 0.04;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        const currentAlpha = p.alpha * (0.6 + 0.4 * Math.sin(p.pulse));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${currentAlpha})`;
        ctx.shadowColor = 'rgba(56, 189, 248, 0.8)';
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleMasukClick = () => {
    soundEngine.playClassicMasukSound();
    onEnter();
  };

  return (
    <div className="relative w-full min-h-screen overflow-hidden bg-slate-950 text-white flex flex-col justify-between selection:bg-cyan-500 selection:text-black">
      {/* Background MP4 Video Gojo Satoru */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          onLoadedData={() => setVideoLoaded(true)}
          onError={() => setVideoError(true)}
          className={`w-full h-full object-cover object-center transition-opacity duration-1000 ${
            videoLoaded && !videoError ? 'opacity-40 scale-105' : 'opacity-0'
          }`}
          src="https://assets.mixkit.co/videos/preview/mixkit-cyberpunk-digital-landscape-loop-42866-large.mp4"
        />
        {/* Secondary fallback video loop */}
        {videoError && (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover object-center opacity-30"
            src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4"
          />
        )}
      </div>

      {/* Canvas Limitless Void overlay */}
      <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />

      {/* CRT Scanline & vignette effect */}
      <div className="absolute inset-0 z-10 scanlines pointer-events-none opacity-40" />
      <div className="absolute inset-0 z-10 bg-radial-gradient from-transparent via-slate-950/40 to-slate-950/90 pointer-events-none" />

      {/* Top Navbar Header */}
      <header className="relative z-20 w-full px-4 sm:px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 p-[2px] shadow-lg shadow-cyan-500/30 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <span className="font-pixel text-xs text-cyan-400 font-bold">K</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-pixel text-xs sm:text-sm tracking-wider text-cyan-300 drop-shadow-[0_0_8px_rgba(56,189,248,0.7)]">
                krammzlua
              </h1>
              <span className="text-[10px] uppercase font-bold tracking-widest bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/40">
                GOJO EDITION
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Portal Publik & Script Lua / Zip Showcase
            </p>
          </div>
        </div>

        {/* Audio Player & GitHub Zip Export */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Audio controller widget for "Lagu MP3 Kicau Mania" */}
          <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md border border-cyan-500/30 px-3 py-1.5 rounded-full shadow-lg shadow-cyan-900/20">
            <button
              onClick={toggleAudio}
              className="flex items-center gap-2 text-xs font-semibold text-cyan-300 hover:text-white transition-colors"
              title={isPlayingAudio ? 'Matikan Lagu Kicau Mania' : 'Putar Lagu MP3 Kicau Mania'}
            >
              {isPlayingAudio ? (
                <>
                  <Volume2 className="w-4 h-4 text-cyan-400 animate-pulse" />
                  <span className="hidden sm:inline">Kicau Mania: ON</span>
                  <div className="flex items-end gap-[2px] h-3">
                    <span className="w-1 bg-cyan-400 h-full animate-[bounce_0.6s_infinite]"></span>
                    <span className="w-1 bg-cyan-300 h-2/3 animate-[bounce_0.8s_infinite]"></span>
                    <span className="w-1 bg-cyan-200 h-full animate-[bounce_0.5s_infinite]"></span>
                  </div>
                </>
              ) : (
                <>
                  <VolumeX className="w-4 h-4 text-slate-400" />
                  <span className="hidden sm:inline text-slate-300">Lagu Kicau: OFF</span>
                </>
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
              className="w-12 sm:w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              title="Volume"
            />
          </div>

          {/* Download Zip for GitHub button */}
          <button
            onClick={onDownloadGitHubZip}
            className="flex items-center gap-1.5 text-xs font-bold bg-cyan-950/80 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-400/50 px-3.5 py-2 rounded-xl transition-all shadow-md group"
            title="Download krammzlua.zip siap upload ke GitHub"
          >
            <Github className="w-3.5 h-3.5 text-cyan-400 group-hover:rotate-12 transition-transform" />
            <span className="font-bold">Download krammzlua.zip</span>
            <Download className="w-3.5 h-3.5 text-cyan-300" />
          </button>

          {/* Admin Login Quick Link */}
          <button
            onClick={onOpenAdmin}
            className="flex items-center gap-1.5 text-xs font-bold bg-gradient-to-r from-purple-600/80 to-blue-600/80 hover:from-purple-500 hover:to-blue-500 text-white px-3 py-2 rounded-xl border border-purple-400/30 transition-all shadow-md shadow-purple-900/30"
          >
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
            <span>Admin</span>
          </button>
        </div>
      </header>

      {/* Main Center Content: Gojo Satoru Visual & Infinite Void Banner */}
      <main className="relative z-20 flex-1 flex flex-col items-center justify-center px-4 text-center my-4 sm:my-8">
        {/* Animated Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-950/60 border border-cyan-400/40 text-cyan-300 text-xs font-rajdhani font-semibold tracking-wider uppercase mb-5 backdrop-blur-md shadow-[0_0_15px_rgba(56,189,248,0.3)]">
          <Radio className="w-3.5 h-3.5 text-cyan-400 animate-ping" />
          <span>Ryōiki Tenkai • Muryōkūsho (Infinite Void)</span>
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
          <span>By Krammz</span>
        </div>

        {/* Gojo Anime Character Avatar Frame */}
        <div className="relative mb-6 group">
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
          
          <div className="relative w-48 h-48 sm:w-60 sm:h-60 rounded-2xl overflow-hidden border-2 border-cyan-300/80 shadow-2xl bg-slate-900 flex flex-col items-center justify-center">
            {/* Gojo Satoru iconic anime artwork presentation */}
            <img
              src="https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&q=80"
              alt="Gojo Satoru Anime Visual"
              className="w-full h-full object-cover object-center filter saturate-125 contrast-110 group-hover:scale-105 transition-transform duration-700"
              onError={(e) => {
                // Fallback custom Gojo graphic
                (e.currentTarget as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80';
              }}
            />
            {/* Blue Eye Glow overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-cyan-950/30 to-transparent"></div>
            
            <div className="absolute bottom-2 left-0 right-0 px-2 py-1 text-center bg-slate-950/70 backdrop-blur-sm border-t border-cyan-500/30">
              <p className="font-pixel text-[9px] text-cyan-300">SATORU GOJO</p>
              <p className="text-[10px] text-slate-300 font-rajdhani">The Strongest Sorcerer</p>
            </div>
          </div>

          {/* Floating soundwave status when Kicau Mania is singing */}
          {isPlayingAudio && (
            <div className="absolute -top-3 -right-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-[10px] px-2.5 py-1 rounded-full shadow-lg border border-amber-300 flex items-center gap-1 animate-bounce">
              <span>🐦</span>
              <span>Kicau Mania On</span>
            </div>
          )}
        </div>

        {/* Title */}
        <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight font-rajdhani uppercase text-transparent bg-clip-text bg-gradient-to-b from-white via-cyan-100 to-cyan-400 drop-shadow-[0_0_20px_rgba(56,189,248,0.5)] max-w-3xl">
          krammzlua
        </h2>

        {/* Subtitle */}
        <p className="mt-3 text-sm sm:text-base text-slate-300 max-w-xl font-medium leading-relaxed">
          Tempat upload & showcase file <span className="text-cyan-400 font-bold">.PNG</span>,{' '}
          <span className="text-purple-400 font-bold">.ZIP</span>, dan{' '}
          <span className="text-emerald-400 font-bold">.LUA</span>. Semua file yang di-upload dapat diakses & diunduh oleh publik secara gratis!
        </p>

        {/* Music Player Bar (Interactive) */}
        <div className="mt-5 flex items-center justify-center gap-3 bg-slate-900/70 border border-slate-700/60 backdrop-blur-md px-4 py-2 rounded-2xl max-w-md w-full">
          <button
            onClick={toggleAudio}
            className={`p-2 rounded-xl transition-all ${
              isPlayingAudio
                ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/40'
                : 'bg-slate-800 text-cyan-400 hover:bg-slate-700'
            }`}
          >
            {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-cyan-400" />}
          </button>
          <div className="flex-1 text-left">
            <p className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>🎵 Lagu MP3 Kicau Mania</span>
              {isPlayingAudio && (
                <span className="text-[10px] text-cyan-400 bg-cyan-950 px-1.5 py-0.2 rounded font-mono">
                  LIVE
                </span>
              )}
            </p>
            <p className="text-[11px] text-slate-400">
              {isPlayingAudio
                ? 'Suara kicauan burung Murai Batu, Kenari & Lovebird aktif'
                : 'Tekan putar untuk mendengarkan lagu kicau mania'}
            </p>
          </div>
        </div>

        {/* Classic Button: "MASUK" (Requested in prompt) */}
        <div className="mt-8 sm:mt-10 flex flex-col items-center">
          <button
            onClick={handleMasukClick}
            className="btn-classic-masuk font-pixel text-base sm:text-xl text-white px-8 sm:px-14 py-4 sm:py-5 rounded-2xl cursor-pointer tracking-widest uppercase flex items-center gap-4 group"
          >
            <span className="text-yellow-300 group-hover:scale-125 transition-transform">▶</span>
            <span>MASUK</span>
            <span className="text-yellow-300 group-hover:scale-125 transition-transform">◀</span>
          </button>
          <p className="mt-3 text-xs text-cyan-300/80 font-mono tracking-wider">
            [ KLIK TOMBOL MASUK UNTUK MEMBUKA HALAMAN PUBLIK ]
          </p>
        </div>
      </main>

      {/* Footer Info & Quick GitHub helper */}
      <footer className="relative z-20 w-full px-4 sm:px-8 py-4 border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <span className="text-slate-300">
            Dikelola oleh <span className="text-cyan-400 font-bold">krammzlua</span>
          </span>
          <span className="hidden sm:inline text-slate-600">•</span>
          <span className="hidden sm:inline">Siap Upload ke GitHub (.Zip)</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onDownloadGitHubZip}
            className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Kirim / Download krammzlua.zip</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
