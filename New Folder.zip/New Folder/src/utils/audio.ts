/**
 * Web Audio API synthesizer for Indonesian "Kicau Mania" (bird songs)
 * and classic retro arcade SFX.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isKicauPlaying = false;
  private kicauTimer: number | null = null;
  private masterGain: GainNode | null = null;
  private volume = 0.5;

  private initCtx() {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtxClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public getVolume() {
    return this.volume;
  }

  public isPlaying() {
    return this.isKicauPlaying;
  }

  /**
   * Generates a single bird chirp with pitch bend and harmonic overtones (Murai Batu / Kenari motif)
   */
  public playSingleChirp(type: 'kenari' | 'murai' | 'lovebird' = 'murai') {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc2.type = 'triangle';

    if (type === 'murai') {
      // Murai Batu high-low melodic trill
      const baseFreq = 2200 + Math.random() * 800;
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.8, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.9, now + 0.18);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, now + 0.28);

      osc2.frequency.setValueAtTime(baseFreq * 2, now);
      osc2.frequency.exponentialRampToValueAtTime(baseFreq * 3, now + 0.15);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.35, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc2.start(now);
      osc.stop(now + 0.33);
      osc2.stop(now + 0.33);
    } else if (type === 'kenari') {
      // Kenari fast rolling vibration
      const baseFreq = 3200 + Math.random() * 400;
      osc.frequency.setValueAtTime(baseFreq, now);
      for (let i = 0; i < 6; i++) {
        osc.frequency.setValueAtTime(baseFreq + 300, now + i * 0.04);
        osc.frequency.setValueAtTime(baseFreq - 200, now + i * 0.04 + 0.02);
      }

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.25, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.26);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.27);
    } else {
      // Lovebird sharp chirp
      const baseFreq = 2800 + Math.random() * 600;
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.4, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.7, now + 0.14);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.3, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.17);
    }
  }

  /**
   * Starts rhythmic and lively Kicau Mania ambient loop
   */
  public startKicauMania() {
    this.initCtx();
    this.isKicauPlaying = true;

    const playSequence = () => {
      if (!this.isKicauPlaying) return;

      const types: ('kenari' | 'murai' | 'lovebird')[] = ['murai', 'kenari', 'lovebird', 'murai'];
      const chosenType = types[Math.floor(Math.random() * types.length)];

      const repeats = Math.floor(Math.random() * 3) + 1;
      for (let r = 0; r < repeats; r++) {
        setTimeout(() => {
          if (this.isKicauPlaying) {
            this.playSingleChirp(chosenType);
          }
        }, r * 140);
      }

      // Next bird sings in 400ms - 1400ms
      const nextDelay = 500 + Math.random() * 900;
      this.kicauTimer = window.setTimeout(playSequence, nextDelay);
    };

    playSequence();
  }

  public stopKicauMania() {
    this.isKicauPlaying = false;
    if (this.kicauTimer !== null) {
      clearTimeout(this.kicauTimer);
      this.kicauTimer = null;
    }
  }

  public toggleKicauMania(): boolean {
    if (this.isKicauPlaying) {
      this.stopKicauMania();
      return false;
    } else {
      this.startKicauMania();
      return true;
    }
  }

  /**
   * Classic retro arcade button press SFX (for "MASUK" button)
   */
  public playClassicMasukSound() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;

    const now = this.ctx.currentTime;
    
    // Low sub hit
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(150, now);
    sub.frequency.exponentialRampToValueAtTime(40, now + 0.4);
    subGain.gain.setValueAtTime(0.5, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    sub.connect(subGain);
    subGain.connect(this.masterGain);
    sub.start(now);
    sub.stop(now + 0.45);

    // Limitless / Domain Expansion shimmer chord
    const freqs = [523.25, 659.25, 783.99, 1046.5]; // C E G C (Maj)
    freqs.forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + i * 0.05);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + 0.5);

      gain.gain.setValueAtTime(0, now + i * 0.05);
      gain.gain.linearRampToValueAtTime(0.2, now + i * 0.05 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + i * 0.05);
      osc.stop(now + 0.65);
    });
  }

  /**
   * Success notification chime
   */
  public playSuccessSound() {
    this.initCtx();
    if (!this.ctx || !this.masterGain) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(587.33, now); // D5
    osc.frequency.setValueAtTime(880, now + 0.1); // A5
    osc.frequency.setValueAtTime(1174.66, now + 0.2); // D6

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.3, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.5);
  }
}

export const soundEngine = new SoundEngine();
