export interface UploadedItem {
  id: string;
  title: string;
  description: string;
  imagePngUrl: string;
  imageFileName: string;
  fileType: 'zip' | 'lua';
  fileUrl: string;
  fileName: string;
  fileSize: string;
  luaContent?: string;
  uploadedAt: string;
  uploader: string;
  downloadsCount: number;
  viewsCount: number;
  category: string;
}

export type ActivePage = 'landing' | 'showcase';
