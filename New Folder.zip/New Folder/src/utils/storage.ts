import { UploadedItem } from '../types';

const STORAGE_KEY = 'krammzlua_public_uploads_v2';

// Preset sample PNG visual base64 generators for instant rendering
export const createSamplePngDataUrl = (title: string, subtitle: string, color: string = '#0284c7'): string => {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 360;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background gradient
  const grad = ctx.createLinearGradient(0, 0, 640, 360);
  grad.addColorStop(0, '#020617');
  grad.addColorStop(0.5, '#0f172a');
  grad.addColorStop(1, '#082f49');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 640, 360);

  // Geometric Jujutsu Kaisen cursed energy circles
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.globalAlpha = 0.3;
  for (let i = 1; i <= 4; i++) {
    ctx.beginPath();
    ctx.arc(320, 180, i * 45, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  // Glow orb in center
  const glow = ctx.createRadialGradient(320, 150, 10, 320, 150, 140);
  glow.addColorStop(0, 'rgba(56, 189, 248, 0.5)');
  glow.addColorStop(0.5, 'rgba(168, 85, 247, 0.2)');
  glow.addColorStop(1, 'transparent');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(320, 150, 140, 0, Math.PI * 2);
  ctx.fill();

  // Text title
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 26px sans-serif';
  ctx.textAlign = 'center';
  ctx.shadowColor = 'rgba(56, 189, 248, 0.9)';
  ctx.shadowBlur = 12;
  ctx.fillText(title, 320, 180);

  // Subtitle
  ctx.fillStyle = '#38bdf8';
  ctx.font = '600 16px sans-serif';
  ctx.shadowBlur = 4;
  ctx.fillText(subtitle, 320, 215);

  // Watermark
  ctx.fillStyle = '#94a3b8';
  ctx.font = '12px monospace';
  ctx.fillText('UPLOADED BY KRAMMZ // VERIFIED PUBLIC SCRIPT', 320, 330);

  return canvas.toDataURL('image/png');
};

const DEFAULT_ITEMS: UploadedItem[] = [
  {
    id: 'krammz-item-1',
    title: 'Gojo Satoru Infinite Void Domain Script V4',
    description: 'Script Lua efek Domain Expansion Muryokusho (Infinite Void) dengan visual partikel aura biru, sound effect anime, dan screen distortion.',
    imagePngUrl: '', // generated on load
    imageFileName: 'gojo_infinite_void_preview.png',
    fileType: 'lua',
    fileUrl: '',
    fileName: 'Gojo_Infinite_Void_v4.lua',
    fileSize: '18.4 KB',
    luaContent: `-- [[ KRAMMZLUA // GOJO SATORU DOMAIN EXPANSION SCRIPT ]]
-- Author: Krammz
-- Type: Universal Lua Script / Roblox Executor Ready

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local LocalPlayer = Players.LocalPlayer

local function activateDomainExpansion()
    print("[KRAMMZ HUB] Ryōiki Tenkai: Muryōkūsho! (Infinite Void Activated)")
    
    -- Visual Aura Notification
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://9114223178"
    sound.Volume = 1
    sound.Parent = workspace
    sound:Play()

    -- Stun all targets in 50 stud radius
    local char = LocalPlayer.Character
    if char and char:FindFirstChild("HumanoidRootPart") then
        local myPos = char.HumanoidRootPart.Position
        for _, p in pairs(Players:GetPlayers()) do
            if p ~= LocalPlayer and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
                local dist = (p.Character.HumanoidRootPart.Position - myPos).Magnitude
                if dist < 65 then
                    print("[KRAMMZ] Freezing target: " .. p.Name)
                end
            end
        end
    end
end

-- Keybind activation: Press 'V' to cast
game:GetService("UserInputService").InputBegan:Connect(function(input, gp)
    if not gp and input.KeyCode == Enum.KeyCode.V then
        activateDomainExpansion()
    end
end)

print("[KRAMMZ HUB] Script Loaded Successfully! Press 'V' to activate.")`,
    uploadedAt: 'Hari ini, 00:15 WIB',
    uploader: 'Krammz (Admin)',
    downloadsCount: 142,
    viewsCount: 689,
    category: 'Lua Script'
  },
  {
    id: 'krammz-item-2',
    title: 'Blox Fruit & Blade Ball Auto-Farm Krammz Edition.zip',
    description: 'Paket arsip ZIP lengkap berisi script Lua loader, config JSON, asset sound effect, dan petunjuk eksekusi injector.',
    imagePngUrl: '',
    imageFileName: 'blox_fruit_krammz_pack.png',
    fileType: 'zip',
    fileUrl: '',
    fileName: 'Blox_Fruit_Krammz_v2.5.zip',
    fileSize: '2.4 MB',
    uploadedAt: 'Kemarin, 21:40 WIB',
    uploader: 'Krammz (Admin)',
    downloadsCount: 388,
    viewsCount: 1205,
    category: 'Zip Archive'
  },
  {
    id: 'krammz-item-3',
    title: 'FiveM Krammz Custom Speedometer & HUD UI.zip',
    description: 'Arsip ZIP UI speedometer modern untuk FiveM server dengan gauge neon cyan, rpm meter, fuel indicator, dan sound chime.',
    imagePngUrl: '',
    imageFileName: 'fivem_hud_preview.png',
    fileType: 'zip',
    fileUrl: '',
    fileName: 'FiveM_Krammz_HUD_UI.zip',
    fileSize: '4.8 MB',
    uploadedAt: '3 hari yang lalu',
    uploader: 'Krammz (Admin)',
    downloadsCount: 215,
    viewsCount: 750,
    category: 'Zip Archive'
  },
  {
    id: 'krammz-item-4',
    title: 'Universal Roblox ESP & Aimbot Silent V2.lua',
    description: 'Script Lua ESP Box, Tracer, Skeleton, dan FOV Circle dengan performa 60 FPS tanpa drop frame. Dilengkapi menu GUI toggle.',
    imagePngUrl: '',
    imageFileName: 'esp_aimbot_showcase.png',
    fileType: 'lua',
    fileUrl: '',
    fileName: 'Krammz_Silent_ESP_v2.lua',
    fileSize: '24.1 KB',
    luaContent: `-- [[ KRAMMZ HUB // UNIVERSAL SILENT ESP & AIMBOT ]]
-- Created by Krammz
-- Clean code, smooth drawing library

local Camera = workspace.CurrentCamera
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local Settings = {
    ESP_Enabled = true,
    BoxColor = Color3.fromRGB(56, 189, 248),
    ShowNames = true,
    ShowDistance = true,
    TeamCheck = false
}

print("[KRAMMZ HUB] Universal ESP initialized!")
-- Toggle via UI or Insert key`,
    uploadedAt: '4 hari yang lalu',
    uploader: 'Krammz (Admin)',
    downloadsCount: 520,
    viewsCount: 1940,
    category: 'Lua Script'
  }
];

export const getStoredItems = (): UploadedItem[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed: UploadedItem[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error('Failed to load items from storage:', err);
  }

  // Populate default images on first run
  const initial = DEFAULT_ITEMS.map((item) => {
    const img = createSamplePngDataUrl(item.title, item.category === 'Lua Script' ? 'LUA SCRIPT' : 'ZIP ARCHIVE');
    return {
      ...item,
      imagePngUrl: img
    };
  });

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  } catch {
    // Ignore quota issues
  }

  return initial;
};

export const saveNewItem = (item: UploadedItem): UploadedItem[] => {
  const current = getStoredItems();
  const updated = [item, ...current];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('LocalStorage save failed, keeping in memory', err);
  }
  return updated;
};

export const deleteStoredItem = (id: string): UploadedItem[] => {
  const current = getStoredItems();
  const updated = current.filter((item) => item.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn('LocalStorage delete failed', err);
  }
  return updated;
};

export const incrementDownloadCount = (id: string) => {
  const current = getStoredItems();
  const updated = current.map((item) => {
    if (item.id === id) {
      return { ...item, downloadsCount: item.downloadsCount + 1 };
    }
    return item;
  });
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
};
