import JSZip from 'jszip';

export const downloadTextOrBlobFile = (filename: string, content: string | Blob, mimeType: string = 'text/plain') => {
  const blob = content instanceof Blob ? content : new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

export const generateGitHubProjectZip = async (onProgress?: (percent: number, step: string) => void) => {
  onProgress?.(15, 'Mengunduh paket krammzlua.zip lengkap...');
  try {
    const res = await fetch('/krammzlua.zip');
    if (res.ok) {
      const blob = await res.blob();
      onProgress?.(80, 'Memverifikasi berkas zip...');
      downloadTextOrBlobFile('krammzlua.zip', blob, 'application/zip');
      onProgress?.(100, 'Berhasil mengunduh krammzlua.zip!');
      return;
    }
  } catch (e) {
    console.log('Falling back to browser JSZip generation...', e);
  }

  const zip = new JSZip();
  onProgress?.(25, 'Menyiapkan berkas proyek krammzlua...');

  // README with clear Indonesian GitHub instructions (NO PASSWORD LEAK!)
  const readmeContent = `# krammzlua - Gojo Portal & Script Showcase
Website publik **krammzlua** dengan animasi video Gojo Satoru, audio kicau mania, showcase upload PNG / ZIP / LUA, dan panel admin.

## 🚀 Cara Cepat Upload ke GitHub:
1. Buka [https://github.com/new](https://github.com/new) di browser Anda.
2. Beri nama repository, contoh: \`krammzlua\`, lalu klik **Create repository**.
3. Pada halaman repo baru, klik link **"uploading an existing file"**.
4. Ekstrak file **krammzlua.zip** ini di komputer/HP Anda, lalu **drag & drop semua file** ke halaman GitHub tersebut.
5. Klik tombol hijau **Commit changes**.
6. Selesai! Repository Anda sudah aktif di GitHub dan bisa di-deploy ke Vercel atau Netlify hanya dengan 1 klik!

## 💻 Menjalankan di Lokal (Localhost):
\`\`\`bash
# 1. Install dependencies
npm install

# 2. Jalankan server lokal
npm run dev
\`\`\`

Dikelola oleh **krammzlua**.
`;

  zip.file('README.md', readmeContent);

  onProgress?.(25, 'Mengemas package.json & konfigurasi...');

  zip.file(
    'package.json',
    JSON.stringify(
      {
        name: 'krammzlua',
        private: true,
        version: '1.0.0',
        type: 'module',
        scripts: {
          dev: 'vite',
          build: 'vite build',
          preview: 'vite preview'
        },
        dependencies: {
          'lucide-react': '^0.546.0',
          motion: '^12.23.24',
          react: '^19.0.1',
          'react-dom': '^19.0.1',
          jszip: '^3.10.1',
          '@tailwindcss/vite': '^4.3.3',
          '@vitejs/plugin-react': '^6.1.1',
          vite: '^8.3.0',
          tailwindcss: '^4.3.3'
        },
        devDependencies: {
          '@types/node': '^22.14.0',
          '@types/react': '^19.3.0',
          '@types/react-dom': '^19.3.0',
          typescript: '^7.0.2',
          '@types/jszip': '^3.4.1'
        }
      },
      null,
      2
    )
  );

  zip.file(
    'index.html',
    `<!doctype html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>krammzlua - Gojo Portal & Script Showcase</title>
    <meta name="description" content="Portal publik animasi Gojo Satoru dengan kicau mania, showcase upload PNG, ZIP, dan LUA script, serta dashboard admin krammzlua." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Rajdhani:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  </head>
  <body class="bg-slate-950 text-slate-100 antialiased selection:bg-cyan-500 selection:text-black">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`
  );

  zip.file(
    'vite.config.ts',
    `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
});`
  );

  zip.file(
    'tsconfig.json',
    `{
  "compilerOptions": {
    "target": "ES2022",
    "useDefineForClassFields": false,
    "module": "ESNext",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "allowJs": true,
    "jsx": "react-jsx",
    "noEmit": true
  },
  "include": ["src"]
}`
  );

  zip.file(
    '.gitignore',
    `node_modules
dist
dist-ssr
*.local
.env
.DS_Store`
  );

  onProgress?.(50, 'Mengemas seluruh komponen React src/...');

  const srcFolder = zip.folder('src');
  if (srcFolder) {
    srcFolder.file(
      'main.tsx',
      `import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);`
    );

    srcFolder.file(
      'index.css',
      `@import "tailwindcss";

@layer utilities {
  .font-pixel {
    font-family: 'Press Start 2P', monospace, cursive;
  }
  .font-rajdhani {
    font-family: 'Rajdhani', sans-serif;
  }
}

.btn-classic-masuk {
  position: relative;
  background: linear-gradient(180deg, #38bdf8 0%, #0284c7 40%, #0369a1 80%, #075985 100%);
  border: 4px solid #bae6fd;
  box-shadow: 
    0 0 0 3px #082f49,
    0 8px 0 3px #033758,
    0 12px 25px rgba(56, 189, 248, 0.6),
    inset 0 3px 0 rgba(255, 255, 255, 0.6),
    inset 0 -4px 0 rgba(0, 0, 0, 0.4);
  transition: all 0.12s cubic-bezier(0.4, 0, 0.2, 1);
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.7);
}

.btn-classic-masuk:hover {
  transform: translateY(-2px);
  filter: brightness(1.1);
}

.btn-classic-masuk:active {
  transform: translateY(6px);
}

.scanlines {
  background: linear-gradient(
    rgba(18, 16, 16, 0) 50%, 
    rgba(0, 0, 0, 0.25) 50%
  ), linear-gradient(
    90deg,
    rgba(255, 0, 0, 0.03),
    rgba(0, 255, 0, 0.01),
    rgba(0, 255, 0, 0.03)
  );
  background-size: 100% 4px, 6px 100%;
  pointer-events: none;
}`
    );

    srcFolder.file(
      'types.ts',
      `export interface UploadedItem {
  id: string;
  title: string;
  description: string;
  imagePngUrl: string;
  imageFileName: string;
  fileType: 'zip' | 'lua';
  fileUrl: string;
  fileName: string;
  fileSize: string;
  luaContent?: string;
  uploadedAt: string;
  uploader: string;
  downloadsCount: number;
  viewsCount: number;
  category: string;
}

export type ActivePage = 'landing' | 'showcase';`
    );

    srcFolder.file(
      'KRAMMZLUA_README.txt',
      `krammzlua Repository
Selamat! File zip ini siap langsung di-upload ke GitHub.
Drag & drop ke repo GitHub Anda.`
    );
  }

  onProgress?.(80, 'Mengompresi arsip zip krammzlua.zip...');
  const blob = await zip.generateAsync({ type: 'blob' }, (metadata) => {
    onProgress?.(80 + Math.floor(metadata.percent * 0.18), `Mengompres: ${Math.floor(metadata.percent)}%`);
  });

  onProgress?.(100, 'Selesai! Memulai unduhan krammzlua.zip...');
  downloadTextOrBlobFile('krammzlua.zip', blob, 'application/zip');
};
