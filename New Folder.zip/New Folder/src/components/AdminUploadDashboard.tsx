import React, { useState, useRef } from 'react';
import {
  Upload,
  Image as ImageIcon,
  FileCode,
  FolderArchive,
  CheckCircle,
  AlertCircle,
  Eye,
  Trash2,
  Sparkles,
  Download,
  Github,
  LogOut,
  ArrowLeft,
  FileText
} from 'lucide-react';
import { UploadedItem } from '../types';
import { createSamplePngDataUrl, saveNewItem, deleteStoredItem } from '../utils/storage';
import { soundEngine } from '../utils/audio';

interface AdminUploadDashboardProps {
  items: UploadedItem[];
  onItemsChange: (items: UploadedItem[]) => void;
  onBackToPublic: () => void;
  onLogout: () => void;
  onOpenGitHubZip: () => void;
}

export const AdminUploadDashboard: React.FC<AdminUploadDashboardProps> = ({
  items,
  onItemsChange,
  onBackToPublic,
  onLogout,
  onOpenGitHubZip
}) => {
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'Lua Script' | 'Zip Archive' | 'Roblox Mod' | 'FiveM Asset'>('Lua Script');
  
  // Image PNG state
  const [pngFile, setPngFile] = useState<File | null>(null);
  const [pngPreviewUrl, setPngPreviewUrl] = useState<string>('');
  
  // Script / Zip file state
  const [scriptOrZipFile, setScriptOrZipFile] = useState<File | null>(null);
  const [fileType, setFileType] = useState<'lua' | 'zip'>('lua');
  const [luaCodeText, setLuaCodeText] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const pngInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Handle PNG image selection
  const handlePngChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.name.toLowerCase().endsWith('.png') && !file.type.includes('png') && !file.type.includes('image')) {
        setErrorMessage('Mohon pilih file format gambar (.png)!');
        return;
      }
      setPngFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        setPngPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
      setErrorMessage('');
    }
  };

  // Handle .zip or .lua file selection
  const handleScriptOrZipChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const lower = file.name.toLowerCase();
      if (lower.endsWith('.lua')) {
        setFileType('lua');
        setScriptOrZipFile(file);
        // Read text content for Lua preview/copying
        const reader = new FileReader();
        reader.onload = () => {
          setLuaCodeText(reader.result as string);
        };
        reader.readAsText(file);
      } else if (lower.endsWith('.zip')) {
        setFileType('zip');
        setScriptOrZipFile(file);
      } else {
        setErrorMessage('File harus berformat .zip atau .lua!');
        return;
      }
      setErrorMessage('');
    }
  };

  // Submit and publish to Public Showcase
  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!title.trim()) {
      setErrorMessage('Nama file / judul wajib diisi!');
      return;
    }

    if (!scriptOrZipFile && !luaCodeText.trim()) {
      setErrorMessage('Silakan upload file .zip atau .lua terlebih dahulu!');
      return;
    }

    setIsSubmitting(true);

    // Format file size
    const sizeStr = scriptOrZipFile
      ? (scriptOrZipFile.size / 1024 < 1000
          ? `${(scriptOrZipFile.size / 1024).toFixed(1)} KB`
          : `${(scriptOrZipFile.size / (1024 * 1024)).toFixed(1)} MB`)
      : '12.5 KB';

    // Image URL: use uploaded PNG preview or generate a customized Gojo banner PNG
    const finalPngUrl = pngPreviewUrl || createSamplePngDataUrl(title, fileType.toUpperCase(), '#38bdf8');
    const finalFileName = scriptOrZipFile ? scriptOrZipFile.name : `${title.replace(/\s+/g, '_')}.${fileType}`;

    const newItem: UploadedItem = {
      id: `krammz-${Date.now()}`,
      title: title.trim(),
      description: description.trim() || `File ${finalFileName} di-upload oleh Krammz ke portal publik.`,
      imagePngUrl: finalPngUrl,
      imageFileName: pngFile ? pngFile.name : `${title.replace(/\s+/g, '_')}_preview.png`,
      fileType: fileType,
      fileUrl: '',
      fileName: finalFileName,
      fileSize: sizeStr,
      luaContent: fileType === 'lua' ? (luaCodeText || `-- [[ ${title} ]]\nprint("Loaded from Krammz Hub")`) : undefined,
      uploadedAt: 'Baru saja',
      uploader: 'Krammz (Admin)',
      downloadsCount: 0,
      viewsCount: 1,
      category: category
    };

    const updated = saveNewItem(newItem);
    onItemsChange(updated);

    soundEngine.playSuccessSound();
    setIsSubmitting(false);
    setSuccessMessage(`Berhasil mempublikasikan "${title}"! Sekarang sudah tayang di Halaman Kedua (Publik).`);

    // Reset form
    setTitle('');
    setDescription('');
    setPngFile(null);
    setPngPreviewUrl('');
    setScriptOrZipFile(null);
    setLuaCodeText('');
    if (pngInputRef.current) pngInputRef.current.value = '';
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDeleteItem = (id: string, itemTitle: string) => {
    if (confirm(`Yakin ingin menghapus file "${itemTitle}" dari publik?`)) {
      const updated = deleteStoredItem(id);
      onItemsChange(updated);
      setSuccessMessage(`File "${itemTitle}" telah dihapus.`);
    }
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-8">
      {/* Top Bar Navigation */}
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToPublic}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors flex items-center gap-2 text-xs font-bold"
            title="Kembali ke Showcase Publik"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Lihat Tampilan Publik</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold font-rajdhani uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
                PANEL ADMIN KRAMMZLUA
              </h1>
              <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2 py-0.5 rounded-full font-bold">
                SUPER ADMIN
              </span>
            </div>
            <p className="text-xs text-slate-400">Halo Krammz! Upload file untuk ditampilkan langsung ke publik krammzlua.</p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-end">
          {/* GitHub ZIP button */}
          <button
            onClick={onOpenGitHubZip}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-cyan-950/80 hover:bg-cyan-900/80 text-cyan-300 border border-cyan-400/50 transition-all shadow-md group"
          >
            <Github className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
            <span>Download krammzlua.zip</span>
          </button>

          {/* Logout */}
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-red-950/40 hover:bg-red-900/40 text-red-300 border border-red-500/30 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Form Upload */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
          <div className="flex items-center gap-3 pb-4 mb-6 border-b border-slate-800">
            <div className="p-3 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">Form Upload Publik Krammz</h2>
              <p className="text-xs text-slate-400">
                Format yang diminta: Foto <b>.PNG</b>, lalu file <b>.ZIP</b> atau <b>.LUA</b>, dan <b>Nama File</b>.
              </p>
            </div>
          </div>

          {successMessage && (
            <div className="mb-6 p-4 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-6 p-4 rounded-xl bg-red-950/70 border border-red-500/50 text-red-300 text-xs flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handlePublish} className="space-y-5">
            {/* 1. Input Nama File yang Ditulis */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-cyan-300 mb-1.5 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span>1. Nama File / Judul (Wajib)</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Contoh: Gojo Satoru Infinite Void v5 atau Roblox Auto Farm.zip"
                className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 rounded-xl px-4 py-3 text-sm text-white outline-none transition-all placeholder:text-slate-600"
                required
              />
              <p className="text-[11px] text-slate-400 mt-1">Nama ini akan muncul di bawah file ZIP/LUA pada halaman publik.</p>
            </div>

            {/* 2. Upload Gambar .PNG */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-cyan-300 mb-1.5 flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-cyan-400" />
                <span>2. Upload Gambar Preview (.PNG)</span>
              </label>
              
              <div
                onClick={() => pngInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
                  pngPreviewUrl
                    ? 'border-cyan-400/80 bg-slate-950/60'
                    : 'border-slate-700 hover:border-cyan-500/60 bg-slate-950/40 hover:bg-slate-950/70'
                }`}
              >
                <input
                  ref={pngInputRef}
                  type="file"
                  accept="image/png,image/*"
                  onChange={handlePngChange}
                  className="hidden"
                />

                {pngPreviewUrl ? (
                  <div className="flex flex-col items-center">
                    <img
                      src={pngPreviewUrl}
                      alt="Preview PNG"
                      className="w-full max-h-48 object-cover rounded-lg border border-cyan-500/40 mb-2 shadow-lg"
                    />
                    <p className="text-xs text-cyan-300 font-medium">
                      ✓ Gambar terpilih: {pngFile ? pngFile.name : 'Gambar PNG'} (Klik untuk ganti)
                    </p>
                  </div>
                ) : (
                  <div className="py-4 flex flex-col items-center justify-center">
                    <ImageIcon className="w-8 h-8 text-cyan-400/80 mb-2" />
                    <p className="text-xs font-bold text-slate-200">Klik untuk upload foto .PNG</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      (Jika dikosongkan, banner Gojo PNG otomatis dibuatkan untuk Anda)
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* 3. Upload File .ZIP atau .LUA */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-cyan-300 mb-1.5 flex items-center gap-1.5">
                <FolderArchive className="w-3.5 h-3.5 text-cyan-400" />
                <span>3. Upload Berkas (.ZIP atau .LUA)</span>
              </label>

              {/* Type Switcher */}
              <div className="flex items-center gap-2 mb-2">
                <button
                  type="button"
                  onClick={() => setFileType('lua')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                    fileType === 'lua'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>File .LUA (Script)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFileType('zip')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                    fileType === 'zip'
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/50'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  <FolderArchive className="w-3.5 h-3.5" />
                  <span>Folder / Berkas .ZIP</span>
                </button>
              </div>

              <div
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
                  scriptOrZipFile
                    ? 'border-emerald-400/80 bg-slate-950/60'
                    : 'border-slate-700 hover:border-emerald-500/60 bg-slate-950/40 hover:bg-slate-950/70'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".zip,.lua"
                  onChange={handleScriptOrZipChange}
                  className="hidden"
                />

                {scriptOrZipFile ? (
                  <div className="flex items-center justify-center gap-3">
                    {fileType === 'lua' ? (
                      <FileCode className="w-8 h-8 text-emerald-400" />
                    ) : (
                      <FolderArchive className="w-8 h-8 text-purple-400" />
                    )}
                    <div className="text-left">
                      <p className="text-xs font-bold text-white">{scriptOrZipFile.name}</p>
                      <p className="text-[11px] text-slate-400">
                        Ukuran: {(scriptOrZipFile.size / 1024).toFixed(1)} KB • Tipe: {fileType.toUpperCase()}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="py-3 flex flex-col items-center justify-center">
                    <Upload className="w-7 h-7 text-emerald-400/80 mb-1" />
                    <p className="text-xs font-bold text-slate-200">
                      Pilih file <b>.{fileType.toUpperCase()}</b> dari komputer/HP Anda
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">Dapat berupa script .lua atau arsip .zip</p>
                  </div>
                )}
              </div>

              {/* Optional Lua code text editor if user wants to write/paste script directly */}
              {fileType === 'lua' && (
                <div className="mt-3">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] font-semibold text-slate-400">
                      Atau ketik/paste kode Lua script di sini:
                    </label>
                    <span className="text-[10px] text-cyan-400 font-mono">Roblox / FiveM Executor Ready</span>
                  </div>
                  <textarea
                    rows={4}
                    value={luaCodeText}
                    onChange={(e) => setLuaCodeText(e.target.value)}
                    placeholder="-- Paste Lua script di sini..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-xs text-cyan-300 focus:border-cyan-400 outline-none"
                  />
                </div>
              )}
            </div>

            {/* 4. Deskripsi & Kategori */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Kategori</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-cyan-400"
                >
                  <option value="Lua Script">Lua Script (Roblox / Game)</option>
                  <option value="Zip Archive">Zip Archive (Package)</option>
                  <option value="Roblox Mod">Roblox Mod & GUI</option>
                  <option value="FiveM Asset">FiveM Script & Asset</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Deskripsi Singkat</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Keterangan singkat fungsi script/zip"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-cyan-400 placeholder:text-slate-600"
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 rounded-xl text-sm font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 hover:opacity-95 text-slate-950 font-rajdhani uppercase tracking-wider shadow-lg shadow-cyan-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
              >
                <Sparkles className="w-5 h-5 text-slate-950" />
                <span>{isSubmitting ? 'Mempublikasikan...' : 'Publikasikan ke Publik Sekarang'}</span>
              </button>
              <p className="text-center text-[11px] text-slate-400 mt-2">
                Setelah dipublikasikan, item langsung muncul di Halaman Kedua (Publik) dengan tata letak: Foto .PNG di atas, file .ZIP/.LUA di bawahnya, dan nama file di bawahnya.
              </p>
            </div>
          </form>
        </div>

        {/* Right Column: Manage Uploaded Items & GitHub Zip quick generator */}
        <div className="lg:col-span-5 space-y-6">
          {/* Quick GitHub Zip Card */}
          <div className="bg-gradient-to-br from-slate-900 to-cyan-950/40 border border-cyan-500/40 rounded-2xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                <Github className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Download .Zip untuk GitHub</h3>
                <p className="text-[11px] text-slate-300">Tinggal upload ke GitHub, udah jadi!</p>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Website ini sudah dibuatkan bundel .ZIP komplit. Anda cukup klik tombol download, lalu upload berkas zip ke repository GitHub Anda.
            </p>
            <button
              onClick={onOpenGitHubZip}
              className="w-full py-2.5 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-rajdhani uppercase tracking-wider flex items-center justify-center gap-2 shadow-md shadow-cyan-500/20 cursor-pointer transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Download .ZIP Siap GitHub</span>
            </button>
          </div>

          {/* List of Current Uploaded Items */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <h3 className="font-bold text-white text-sm">Daftar File Publik ({items.length})</h3>
                <p className="text-[11px] text-slate-400">File yang sedang tayang di halaman publik</p>
              </div>
              <button
                onClick={onBackToPublic}
                className="text-xs text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Lihat Publik</span>
              </button>
            </div>

            <div className="space-y-3 max-h-[440px] overflow-y-auto pr-1">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-xl p-3 flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <img
                      src={item.imagePngUrl}
                      alt={item.title}
                      className="w-12 h-12 rounded-lg object-cover border border-slate-700 shrink-0 bg-slate-900"
                    />
                    <div className="overflow-hidden">
                      <p className="font-bold text-xs text-slate-100 truncate">{item.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span
                          className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${
                            item.fileType === 'lua'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-purple-950 text-purple-300 border border-purple-800'
                          }`}
                        >
                          .{item.fileType.toUpperCase()}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate">{item.fileName}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => handleDeleteItem(item.id, item.title)}
                      className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
                      title="Hapus dari Publik"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
