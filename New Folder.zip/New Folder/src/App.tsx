import React, { useState, useEffect } from 'react';
import { ActivePage, UploadedItem } from './types';
import { getStoredItems } from './utils/storage';
import { GojoLandingPage } from './components/GojoLandingPage';
import { PublicShowcase } from './components/PublicShowcase';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminUploadDashboard } from './components/AdminUploadDashboard';
import { LuaCodeModal } from './components/LuaCodeModal';
import { GitHubZipModal } from './components/GitHubZipModal';

export default function App() {
  const [currentPage, setCurrentPage] = useState<ActivePage>('landing');
  const [items, setItems] = useState<UploadedItem[]>([]);
  
  // Admin auth state
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState(false);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);

  // Modals
  const [selectedLuaItem, setSelectedLuaItem] = useState<UploadedItem | null>(null);
  const [showGitHubZipModal, setShowGitHubZipModal] = useState(false);

  // Load items from persistent storage
  useEffect(() => {
    const loaded = getStoredItems();
    setItems(loaded);
  }, []);

  // Handle "MASUK" button click on Landing page
  const handleEnterShowcase = () => {
    setCurrentPage('showcase');
  };

  // Handle Admin Login Success (Krammz / ikram11abb)
  const handleAdminLoginSuccess = () => {
    setIsAdminLoggedIn(true);
    setShowAdminLoginModal(false);
    setShowAdminDashboard(true);
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setShowAdminDashboard(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans">
      {/* 1. Halaman Awal: Animasi Video Gojo MP4, Kicau Mania & Tombol MASUK */}
      {currentPage === 'landing' && !showAdminDashboard && (
        <GojoLandingPage
          onEnter={handleEnterShowcase}
          onOpenAdmin={() => {
            if (isAdminLoggedIn) {
              setShowAdminDashboard(true);
            } else {
              setShowAdminLoginModal(true);
            }
          }}
          onDownloadGitHubZip={() => setShowGitHubZipModal(true)}
        />
      )}

      {/* 2. Halaman Kedua: Public Showcase dengan Panel Admin di Pojok Kanan */}
      {currentPage === 'showcase' && !showAdminDashboard && (
        <PublicShowcase
          items={items}
          onOpenAdmin={() => setShowAdminLoginModal(true)}
          isAdminLoggedIn={isAdminLoggedIn}
          onOpenAdminDashboard={() => setShowAdminDashboard(true)}
          onViewLua={(item) => setSelectedLuaItem(item)}
          onOpenGitHubZip={() => setShowGitHubZipModal(true)}
          onBackToLanding={() => setCurrentPage('landing')}
        />
      )}

      {/* 3. Panel Admin Dashboard (Setelah Login Krammz: ikram11abb) */}
      {showAdminDashboard && (
        <AdminUploadDashboard
          items={items}
          onItemsChange={(newItems) => setItems(newItems)}
          onBackToPublic={() => {
            setShowAdminDashboard(false);
            setCurrentPage('showcase');
          }}
          onLogout={handleAdminLogout}
          onOpenGitHubZip={() => setShowGitHubZipModal(true)}
        />
      )}

      {/* Modal: Login Admin Krammz */}
      <AdminLoginModal
        isOpen={showAdminLoginModal}
        onClose={() => setShowAdminLoginModal(false)}
        onSuccess={handleAdminLoginSuccess}
      />

      {/* Modal: Lihat & Salin Script LUA */}
      <LuaCodeModal
        item={selectedLuaItem}
        onClose={() => setSelectedLuaItem(null)}
      />

      {/* Modal: Download .ZIP Proyek Siap Upload ke GitHub */}
      <GitHubZipModal
        isOpen={showGitHubZipModal}
        onClose={() => setShowGitHubZipModal(false)}
      />
    </div>
  );
}
