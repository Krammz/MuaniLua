import React, { useState } from 'react';
import { X, Copy, Check, FileCode, Download, Sparkles } from 'lucide-react';
import { UploadedItem } from '../types';
import { downloadTextOrBlobFile } from '../utils/githubZip';
import { soundEngine } from '../utils/audio';

interface LuaCodeModalProps {
  item: UploadedItem | null;
  onClose: () => void;
}

export const LuaCodeModal: React.FC<LuaCodeModalProps> = ({ item, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!item) return null;

  const content = item.luaContent || `-- [[ ${item.title} ]]\n-- File: ${item.fileName}\n-- Uploader: ${item.uploader}\n\nprint("Halo dari ${item.title}!")\n-- Script siap dijalankan di Lua executor.`;

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    soundEngine.playSuccessSound();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    downloadTextOrBlobFile(item.fileName, content, 'text/plain');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[85vh] bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-sm sm:text-base flex items-center gap-2">
                <span>{item.fileName}</span>
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-700/50 px-2 py-0.5 rounded-full">
                  .LUA
                </span>
              </h3>
              <p className="text-xs text-slate-400">Di-upload oleh {item.uploader} • {item.fileSize}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                copied
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin!' : 'Salin Script'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh .lua</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-auto p-4 sm:p-6 bg-slate-950 font-mono text-xs sm:text-sm text-cyan-200/90 leading-relaxed selection:bg-cyan-600 selection:text-white">
          <pre className="whitespace-pre-wrap">{content}</pre>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
            <span>Script publik Krammz Hub • Bebas digunakan</span>
          </div>
          <button onClick={onClose} className="hover:text-slate-200 transition-colors">
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
