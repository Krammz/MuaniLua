import React, { useState } from 'react';
import { X, Github, Download, CheckCircle, FolderArchive, ArrowRight, Sparkles } from 'lucide-react';
import { generateGitHubProjectZip } from '../utils/githubZip';
import { soundEngine } from '../utils/audio';

interface GitHubZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GitHubZipModal: React.FC<GitHubZipModalProps> = ({ isOpen, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('');
  const [completed, setCompleted] = useState(false);

  if (!isOpen) return null;

  const handleStartDownload = async () => {
    setIsGenerating(true);
    setCompleted(false);
    setProgress(0);
    setStatusText('Memulai pembuatan zip...');

    try {
      await generateGitHubProjectZip((percent, step) => {
        setProgress(percent);
        setStatusText(step);
      });
      setCompleted(true);
      soundEngine.playSuccessSound();
    } catch (err) {
      console.error(err);
      setStatusText('Terjadi kendala saat membuat zip.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/50 rounded-2xl shadow-2xl p-6 overflow-hidden">
        {/* Glow corner */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-800 text-cyan-400 border border-slate-700">
              <Github className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base flex items-center gap-2">
                <span>Download krammzlua.zip untuk GitHub</span>
                <span className="text-[10px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-700/40 px-2 py-0.5 rounded-full">
                  SIAP PAKAI
                </span>
              </h3>
              <p className="text-xs text-slate-400">Tinggal upload ke GitHub, beres dan langsung aktif!</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content & Steps */}
        <div className="my-5 space-y-4">
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 text-xs space-y-2.5">
            <p className="font-bold text-cyan-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
              <span>Langkah Cepat Upload ke GitHub:</span>
            </p>
            <div className="flex items-start gap-2 text-slate-300">
              <span className="w-4 h-4 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                1
              </span>
              <span>Klik tombol <b>"Download krammzlua.zip"</b> di bawah ini.</span>
            </div>
            <div className="flex items-start gap-2 text-slate-300">
              <span className="w-4 h-4 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                2
              </span>
              <span>Buka <b>github.com/new</b> di browser, buat repo baru dengan nama <code>krammzlua</code>.</span>
            </div>
            <div className="flex items-start gap-2 text-slate-300">
              <span className="w-4 h-4 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                3
              </span>
              <span>Ekstrak zip atau klik <i>"uploading an existing file"</i> lalu drag semua file ke GitHub. Selesai!</span>
            </div>
          </div>

          {/* Progress bar if generating */}
          {isGenerating && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="font-mono">{statusText}</span>
                <span className="font-bold text-cyan-400">{progress}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Success state */}
          {completed && (
            <div className="flex items-center gap-2.5 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs">
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>
                File <b>krammzlua.zip</b> berhasil di-download! Siap langsung di-upload ke GitHub.
              </span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
          >
            Tutup
          </button>
          <button
            onClick={handleStartDownload}
            disabled={isGenerating}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-rajdhani uppercase tracking-wider shadow-lg shadow-cyan-500/30 disabled:opacity-50 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-950" />
            <span>{isGenerating ? 'Membuat krammzlua.zip...' : 'Download krammzlua.zip'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
